import React from 'react';
import { styled } from 'styled-components';

const Item = styled.li`
	display: flex;
	align-items: center;
	padding: 20px;
	border-bottom: 1px solid #ddd;

	&:hover {
		background-color: #dedede;
		cursor: pointer;
	}
`;

const Title = styled.h2`
	flex: 1 1 0;
	order: 200;
	text-indent: 20px;
`;

const Input = styled.input`
	order: 100;
`;

const Button = styled.button`
	order: 300;
	padding: 5px 8px;
`;

const TodoItem = () => {
	return (
		<Item>
			<Title>리액트 복습</Title>
			<Input type="checkbox" />
			<Button>삭제</Button>
		</Item>
	);
};

export default TodoItem;
