import React from 'react';

const TodoInsert = () => {
	return (
		<div>
			<h1>TodoInsert</h1>
		</div>
	);
};

export default TodoInsert;
