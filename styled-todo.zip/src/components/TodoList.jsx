import React from 'react';
import { styled } from 'styled-components';

import TodoItem from './TodoItem';

const ListContainer = styled.ul`
	height: 500px;
`;

const TodoList = () => {
	return (
		<ListContainer>
			<TodoItem />
			<TodoItem />
			<TodoItem />
			<TodoItem />
			<TodoItem />
			<TodoItem />
		</ListContainer>
	);
};

export default TodoList;
