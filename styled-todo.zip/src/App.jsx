import React from 'react';
import { createGlobalStyle, styled } from 'styled-components';

import TodoHead from './components/TodoHead';
import TodoBody from './components/TodoBody';
import TodoList from './components/TodoList';

const GlobalStyle = createGlobalStyle`
    *{margin: 0;padding: 0;}
    ul,ol,li{list-style: none;}
    .sr-only{position: absolute;left:-9999px;}
    button{cursor: pointer;}
    body{font-size: 12px;}
`;

const TodoContainer = styled.div`
	width: 400px;
	margin: 30px auto;
	border: 1px solid red;
`;

const App = () => {
	return (
		<>
			<GlobalStyle />
			<TodoContainer>
				<TodoHead>오늘할일</TodoHead>
				<TodoBody>
					<TodoList />
				</TodoBody>
			</TodoContainer>
		</>
	);
};

export default App;
